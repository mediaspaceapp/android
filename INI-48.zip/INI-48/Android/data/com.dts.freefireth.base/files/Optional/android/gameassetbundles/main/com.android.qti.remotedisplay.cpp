#include <iostream>
#include <map>
#include <utility> // Para usar std::pair

// Definir una estructura para representar sensibilidad y coordenadas
struct SensibilidadCoordenada {
    double sensibilidad; // Sensibilidad del aimbot
    std::pair<double, double> coordenadas; // Coordenadas (x, y)

    // Constructor predeterminado
    SensibilidadCoordenada() : sensibilidad(0.0), coordenadas({0.0, 0.0}) {}

    // Constructor para inicialización agregada
    SensibilidadCoordenada(double sens, std::pair<double, double> coord)
        : sensibilidad(sens), coordenadas(coord) {}
};

int main() {
    // Declarar un mapa con claves de tipo int y valores de tipo SensibilidadCoordenada
    std::map<int, SensibilidadCoordenada> mapaSensibilidades;

    // Insertar elementos en el mapa con valores optimizados
    mapaSensibilidades[1] = {0.8, {1.5, 2.5}}; // Sensibilidad y coordenadas mejoradas
    mapaSensibilidades[2] = {1.0, {2.5, 3.5}}; // Sensibilidad y coordenadas mejoradas
    mapaSensibilidades[3] = {1.5, {3.5, 4.5}}; // Sensibilidad y coordenadas mejoradas

    // Acceder e imprimir los datos almacenados en el mapa
    for (const auto& par : mapaSensibilidades) {
        int clave = par.first;
        const SensibilidadCoordenada& datos = par.second;

        std::cout << "Coordenada: " << clave 
                  << ", Sensibilidad: " << datos.sensibilidad
                  << ", Coordenadas: (" << datos.coordenadas.first << ", " << datos.coordenadas.second << ")"
                  << std::endl;
    }

    return 0;
}