config = {
    com = {
        dts = {
            freefireth = {
                files = {
                    so = {}
                },
                TXT_SETTING_VIEW = "00000400", -- Aumentado para mayor precisión
                TXT_SETTING_1XSC = "00000500", -- Aumentado para mayor precisión
                TXT_SETTING_2XSC = "00000550", -- Aumentado para mayor precisión
                TXT_SETTING_4XSC = "00000300", -- Ajustado para equilibrio
                TXT_SETTING_8XSC = "00000350", -- Ajustado para equilibrio
                DPI = "00000999", -- DPI al máximo
                Fov = "00000100", -- Campo de visión al máximo
                touchsensitivity = "00000500", -- Sensibilidad táctil aumentada
                X = "00000900", -- Sensibilidad en el eje X aumentada
                Y = "00000900", -- Sensibilidad en el eje Y aumentada
                TXT_SETTING_SENSITIVITY = {
                    ["TXT_SETTING_VIEW"] = "00000315", -- Ajustado para equilibrio
                    ["TXT_SETTING_1XSC"] = "00000300", -- Ajustado para equilibrio
                    ["TXT_SETTING_2XSC"] = "00000348", -- Ajustado para equilibrio
                    ["TXT_SETTING_4XSC"] = "00000345", -- Ajustado para equilibrio
                    ["TXT_SETTING_8XSC"] = "00000125", -- Ajustado para equilibrio
                    ["DPI"] = "00000440", -- DPI ajustado
                    ["Fov"] = "00000100", -- Campo de visión al máximo
                    ["touchsensitivity"] = "00000007", -- Sensibilidad táctil ajustada
                    ["X"] = "00000130", -- Sensibilidad en el eje X ajustada
                    ["Y"] = "00001100", -- Sensibilidad en el eje Y ajustada
                },
                performanceMode = "Ultra", -- Modo de rendimiento máximo
                frameRate = 120, -- FPS objetivo aumentado
                antiCheat = false, -- Anticheat desactivado
                aimlock = {
                    precision = 100.0, -- Precisión de bloqueo de mira al máximo
                    enabled = true -- Bloqueo de mira activado
                },
                aimfov = {
                    value = 90, -- Campo de visión optimizado
                    enabled = true -- Campo de visión activado
                }
            }
        }
    }
}

-- Imprimir valores
print(config.com.dts.freefireth.TXT_SETTING_VIEW) -- Imprime "00000400"
print(config.com.dts.freefireth.TXT_SETTING_SENSITIVITY["TXT_SETTING_VIEW"]) -- Imprime "00000315"