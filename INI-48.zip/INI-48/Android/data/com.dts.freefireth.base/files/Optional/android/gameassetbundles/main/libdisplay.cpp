#include <iostream>
#include <map>
#include <utility> // Para usar std::pair

using namespace std;

struct headSensitivity {
    double sensitivity_x; // Sensibilidad en el eje X
    double sensitivity_y; // Sensibilidad en el eje Y
    pair<double, double> coordinate; // Coordenadas (x, y)

    // Constructor predeterminado
    headSensitivity() : sensitivity_x(0.0), sensitivity_y(0.0), coordinate({0.0, 0.0}) {}

    // Constructor para inicialización agregada
    headSensitivity(double sx, double sy, pair<double, double> coord)
        : sensitivity_x(sx), sensitivity_y(sy), coordinate(coord) {}
};

int main() {
    map<double, headSensitivity> map_sensitivity;

    // Añadir valores al mapa con sensibilidad mejorada
    map_sensitivity[0] = headSensitivity(1000.0, 0.6, {0.6, 1000.0}); // Sensibilidad aumentada
    map_sensitivity[1] = headSensitivity(1000.0, 0.6, {0.6, 1000.0}); // Sensibilidad aumentada
    map_sensitivity[2] = headSensitivity(1000.0, 0.6, {0.6, 1000.0}); // Sensibilidad aumentada

    // Recorrer el mapa y mostrar los valores
    for (const auto& par : map_sensitivity) {
        double key = par.first;
        const headSensitivity& data = par.second;

        // Acceder a los miembros de headSensitivity
        double x = data.sensitivity_x;
        double y = data.sensitivity_y;
        pair<double, double> coordinates = data.coordinate;

        // Imprimir valores
        cout << "Key: " << key 
             << ", Sensitivity (x, y): (" << x << ", " << y << ")"
             << ", Coordinates: (" << coordinates.first << ", " << coordinates.second << ")" << endl;
    }

    return 0;
}