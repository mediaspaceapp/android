-- Incluimos la librería 'pl' para facilitar el manejo de archivos y strings
local pl = require("pl.import_into")()

-- Definición de la clase Vector3
local Vector3 = {
    new = function(self, x, y, z)
        local newVector = { x = x or 0.0, y = y or 0.0, z = z or 0.0 }
        setmetatable(newVector, self)
        self.__index = self
        return newVector
    end
}

-- Definición de la clase GameConfig
local GameConfig = {
    isAiming = false,
    isNoScope = false,
    sensitivityX = 10000.0, -- Sensibilidad máxima en el eje X
    sensitivityY = 10000.0, -- Sensibilidad máxima en el eje Y
    targetPosition = Vector3:new(),
    aimlockChance = 100.0, -- Probabilidad de bloqueo de mira al máximo
    aimFOV = 90.0, -- Campo de visión optimizado
    performanceMode = "Ultra", -- Modo de rendimiento máximo
    frameRate = 120, -- FPS objetivo
    antiCheat = false -- Anticheat desactivado
}

-- Función para cargar la configuración desde un archivo
function GameConfig:loadConfig()
    local configFilePath = system.pathForFile("gameconfig.prop", system.DocumentsDirectory)

    if pl.path.exists(configFilePath) then
        local file = io.open(configFilePath, "r")

        for line in file:lines() do
            local key, value = line:match("([^=]+)=(.+)")
            if key and value then
                key = key:match("^%s*(.-)%s*$") -- Eliminar espacios en blanco
                value = value:match("^%s*(.-)%s*$") -- Eliminar espacios en blanco

                if key == "isAiming" then
                    self.isAiming = value == "true"
                elseif key == "isNoScope" then
                    self.isNoScope = value == "true"
                elseif key == "sensitivityX" then
                    self.sensitivityX = tonumber(value)
                elseif key == "sensitivityY" then
                    self.sensitivityY = tonumber(value)
                elseif key:sub(1, 12) == "targetPosition" then
                    local vectorKey = key:sub(14)
                    if vectorKey == "X" then
                        self.targetPosition.x = tonumber(value)
                    elseif vectorKey == "Y" then
                        self.targetPosition.y = tonumber(value)
                    elseif vectorKey == "Z" then
                        self.targetPosition.z = tonumber(value)
                    end
                elseif key == "aimlockChance" then
                    self.aimlockChance = tonumber(value)
                elseif key == "aimFOV" then
                    self.aimFOV = tonumber(value)
                elseif key == "performanceMode" then
                    self.performanceMode = value
                elseif key == "frameRate" then
                    self.frameRate = tonumber(value)
                elseif key == "antiCheat" then
                    self.antiCheat = value == "true"
                end
            end
        end

        file:close()
    else
        print("Config file not found. Using default values.")
    end
end

-- Función para iniciar la configuración
function GameConfig:start()
    self:loadConfig()
end

-- Crear una instancia de GameConfig y llamar a la función 'start'
local gameConfig = GameConfig
gameConfig:start()

-- Mostrar las propiedades de gameConfig
print("isAiming: " .. tostring(gameConfig.isAiming))
print("sensitivityX: " .. tostring(gameConfig.sensitivityX))
print("sensitivityY: " .. tostring(gameConfig.sensitivityY))
print("aimlockChance: " .. tostring(gameConfig.aimlockChance))
print("aimFOV: " .. tostring(gameConfig.aimFOV))
print("performanceMode: " .. gameConfig.performanceMode)
print("frameRate: " .. tostring(gameConfig.frameRate))
print("antiCheat: " .. tostring(gameConfig.antiCheat))