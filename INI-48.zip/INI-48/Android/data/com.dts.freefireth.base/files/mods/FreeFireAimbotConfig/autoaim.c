#include <SFML/Graphics.hpp>
#include <vector>
#include <cmath>
#include <limits>

class AutoAim
{
public:
    std::string enemyTag = "Enemy"; // Etiqueta para identificar enemigos
    float rotationSpeed = 5.0f; // Velocidad de rotación (aumentada para mayor precisión)
    sf::Transformable* target = nullptr; // Puntero al enemigo más cercano

    void Start()
    {
        FindClosestEnemy();
    }

    void Update(sf::Time elapsedTime)
    {
        if (target)
        {
            // Calcular la dirección hacia el objetivo
            sf::Vector2f direction = target->getPosition() - transformable.getPosition();
            float targetRotation = std::atan2(direction.y, direction.x) * 180 / 3.14159265f; // Convertir a grados

            // Rotar suavemente hacia el objetivo
            float currentRotation = transformable.getRotation();
            float rotationStep = rotationSpeed * elapsedTime.asSeconds();

            if (rotationStep > std::abs(targetRotation - currentRotation))
            {
                transformable.setRotation(targetRotation); // Rotación exacta
            }
            else
            {
                if (targetRotation > currentRotation)
                    transformable.setRotation(currentRotation + rotationStep); // Rotar en sentido horario
                else
                    transformable.setRotation(currentRotation - rotationStep); // Rotar en sentido antihorario
            }
        }
    }

    void FindClosestEnemy()
    {
        std::vector<sf::Transformable*> enemies = GetEnemies(); // Obtener lista de enemigos

        float closestDistance = std::numeric_limits<float>::infinity();
        sf::Transformable* closestEnemy = nullptr;

        // Buscar el enemigo más cercano
        for (sf::Transformable* enemy : enemies)
        {
            sf::Vector2f direction = transformable.getPosition() - enemy->getPosition();
            float distance = std::sqrt(direction.x * direction.x + direction.y * direction.y);

            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestEnemy = enemy;
            }
        }

        if (closestEnemy != nullptr)
        {
            target = closestEnemy; // Asignar el enemigo más cercano como objetivo
        }
    }

private:
    sf::Transformable transformable; // Transformable del jugador

    // Función de ejemplo para obtener enemigos (debes implementarla según tu juego)
    std::vector<sf::Transformable*> GetEnemies()
    {
        std::vector<sf::Transformable*> enemies;
        // Aquí deberías obtener los enemigos de tu juego
        return enemies;
    }
};

int main()
{
    AutoAim autoAim;
    autoAim.Start();

    sf::Clock globalClock;
    while (true)
    {
        sf::Time elapsedTime = globalClock.restart();
        autoAim.Update(elapsedTime);
    }

    return 0;
}