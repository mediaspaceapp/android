using System.Collections.Generic;
using UnityEngine;

// Custom Enemy class
public class Enemy : MonoBehaviour
{
    public Mesh headMesh; // Malla de la cabeza del enemigo
    public bool isMoving; // Indica si el enemigo se está moviendo
}

// Aimbot class
public class Aimbot : MonoBehaviour
{
    public float aimlockChance = 100.0f; // Probabilidad de bloqueo de mira (100% por defecto)
    public float sensitivity = 10000.0f; // Sensibilidad del aimbot
    public float maxDistance = 1000.0f; // Distancia máxima para detectar enemigos

    private List<Enemy> enemies = new List<Enemy>();

    void Start()
    {
        // Inicializar la lista de enemigos
        enemies = new List<Enemy>(FindObjectsOfType<Enemy>());
    }

    void Update()
    {
        if (enemies.Count > 0)
        {
            Enemy closestEnemy = FindClosestEnemy();
            if (closestEnemy != null && Random.Range(0f, 100f) <= aimlockChance)
            {
                AimAtEnemy(closestEnemy);
            }
        }
    }

    private Enemy FindClosestEnemy()
    {
        Enemy closestEnemy = null;
        float closestDistance = Mathf.Infinity;
        Vector3 cameraPosition = Camera.main.transform.position;

        foreach (Enemy enemy in enemies)
        {
            if (enemy == null || !enemy.gameObject.activeInHierarchy) continue;

            float distance = Vector3.Distance(enemy.transform.position, cameraPosition);
            if (distance < closestDistance && distance <= maxDistance)
            {
                closestDistance = distance;
                closestEnemy = enemy;
            }
        }

        return closestEnemy;
    }

    private void AimAtEnemy(Enemy enemy)
    {
        if (enemy.headMesh != null)
        {
            Vector3 closestPoint = GetClosestPointOnMesh(enemy.headMesh, enemy.transform.position);
            Quaternion targetRotation = Quaternion.LookRotation(closestPoint - Camera.main.transform.position);
            Camera.main.transform.rotation = Quaternion.RotateTowards(Camera.main.transform.rotation, targetRotation, sensitivity * Time.deltaTime);
        }
    }

    private Vector3 GetClosestPointOnMesh(Mesh mesh, Vector3 position)
    {
        Vector3[] vertices = mesh.vertices;
        Vector3 closestPoint = Vector3.zero;
        float closestDistance = Mathf.Infinity;

        foreach (Vector3 vertex in vertices)
        {
            Vector3 worldVertex = mesh.transform.TransformPoint(vertex);
            float distance = Vector3.Distance(position, worldVertex);
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestPoint = worldVertex;
            }
        }

        return closestPoint;
    }
}