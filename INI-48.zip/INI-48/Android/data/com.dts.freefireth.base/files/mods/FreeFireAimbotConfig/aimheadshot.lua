-- Configuración principal
display.setStatusBar(display.HiddenStatusBar)
local aspectRatio = display.pixelHeight / display.pixelWidth
display.actualContentHeight = math.floor(1280 * aspectRatio)
display.actualContentWidth = 1280

-- Variables globales
local player = {x = 0, y = 0, rotation = 0}
local target = {x = 0, y = 0}
local aimheadshotEnabled = false
local aimlockEnabled = true

-- Funciones
function calculateAimTarget()
    return {x = target.x, y = target.y}
end

function aimAtTarget(target)
    local dx, dy = target.x - player.x, target.y - player.y
    player.rotation = math.atan2(dy, dx)
end

function enableAimHeadshot()
    aimheadshotEnabled = true
end

function disableAimHeadshot()
    aimheadshotEnabled = false
end

function enableAimHeadshotOnShoot()
    if system.getInfo("environment") == "simulator" then
        -- Habilita el aimheadshot al presionar la tecla 'A' en el simulador
        local function onKeyEvent(event)
            if event.phase == "down" and event.keyName == "a" then
                enableAimHeadshot()
            end
            return false
        end
        Runtime:addEventListener("key", onKeyEvent)
    else
        -- Habilita el aimheadshot al tocar la pantalla en el dispositivo
        local function onTouch(event)
            if event.phase == "began" then
                enableAimHeadshot()
            end
            return false
        end
        display.currentStage:addEventListener("touch", onTouch)
    end
end

function enableAimlock()
    aimlockEnabled = true
end

function disableAimlock()
    aimlockEnabled = false
end

local function update(event)
    -- Actualiza la posición del jugador y el objetivo (si corresponde)
    -- ...

    if aimheadshotEnabled then
        local target = calculateAimTarget()
        aimAtTarget(target)
    end

    if aimlockEnabled then
        local target = calculateAimTarget()
        aimAtTarget(target)
    end
end

-- Configuración de ejemplo para mconfig
local mconfig = {
    sensitivity = 10000, -- Sensibilidad máxima
    aimlock = {
        enemy = {
            target = "HEAD",
            enabled = true
        }
    },
    aimheadshot = {
        ff = {
            player = {
                id = "player",
                head = {
                    id = "head"
                }
            },
            enableAimHeadshot = enableAimHeadshot,
            calculateAimTarget = calculateAimTarget,
            aimAtTarget = aimAtTarget,
            aimbot = function()
                local target = calculateAimTarget()
                aimAtTarget(target)
                timer.performWithDelay(17, aimbot) -- ~60 FPS
            end
        }
    },
    sensitivityWeapon = 10000, -- Sensibilidad del arma al máximo
    aimlockEnemy = {
        enemy = {
            id = "enemy",
            aimlockEnabled = true
        },
        calculateAimTarget = calculateAimTarget,
        aimAtTarget = aimAtTarget,
        aimbot = function()
            if aimlockEnabled then
                local target = calculateAimTarget()
                aimAtTarget(target)
            end
            timer.performWithDelay(17, aimbot) -- ~60 FPS
        end,
        enableAimlock = enableAimlock,
        disableAimlock = disableAimlock
    }
}

-- Carga de configuraciones
local config = {
    sensitivity = mconfig.sensitivity,
    aimlock = mconfig.aimlock,
    aimheadshot = mconfig.aimheadshot,
    sensitivityWeapon = mconfig.sensitivityWeapon,
    aimlockEnemy = mconfig.aimlockEnemy
}

-- Inicialización
Runtime:addEventListener("enterFrame", update)
enableAimHeadshotOnShoot()
enableAimlock()
mconfig.aimheadshot.ff.aimbot()
mconfig.aimlockEnemy.aimbot()