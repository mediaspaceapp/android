#include <jni.h>
#include <string>
#include <tinyxml2.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_registrointhegame_freefire_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string xmlCode =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
        "<DAPT type=\"script\">"
            "<af>af</af>"
            "<co>co (in the game)</co>"
            "<in_the_game>com.dts.freefireth</in_the_game>"
            "<CURSOR_VALUE_GRAVITY>"
                "<CURSOR_1>2019118072</CURSOR_1>"  // Actualizado con el valor proporcionado
                "<CURSOR_2>scope.m.lib</CURSOR_2>"
                "<CURSOR_TYPE_CROSSHAIR>Density type no recoil</CURSOR_TYPE_CROSSHAIR>"
            "</CURSOR_VALUE_GRAVITY>"
            "<CURSOR_TYPE_CROSSHAIR>"
                "<CROSSHAIR>value off system</CROSSHAIR>"
                "<redirect>from query (in the game)</redirect>"
            "</CURSOR_TYPE_CROSSHAIR>"
            "<jexe-aimbot>dapt</jexe-aimbot>"
            "<configuration>"
                "<com.dts.freefireth~[sensitivity]>"
                    "<noRecoil>1.0</noRecoil>"  // Reducción de retroceso al máximo
                    "<aimFov>0.9</aimFov>"      // Campo de visión optimizado
                    "<unfocusedFov>0.8</unfocusedFov>"  // Campo de visión sin enfoque
                "</com.dts.freefireth~[sensitivity]>"
                "<module no recoil in the game>"
                    "<path>GameAssetBundles</path>"
                "</module>"
                "<performance>"
                    "<mode>Ultra</mode>"  // Modo de rendimiento máximo
                    "<frameRate>120</frameRate>"  // FPS objetivo
                "</performance>"
                "<graphics>"
                    "<textureQuality>Ultra</textureQuality>"  // Calidad de texturas máxima
                    "<shadowQuality>High</shadowQuality>"  // Calidad de sombras alta
                    "<effectQuality>High</effectQuality>"  // Calidad de efectos alta
                "</graphics>"
                "<network>"
                    "<latencyReduction>true</latencyReduction>"  // Reducción de latencia activada
                    "<packetOptimization>true</packetOptimization>"  // Optimización de paquetes activada
                "</network>"
            "</configuration>"
        "</DAPT>";

    tinyxml2::XMLDocument doc;
    doc.Parse(xmlCode.c_str());

    tinyxml2::XMLPrinter printer;
    doc.Print(&printer);
    std::string result = printer.CStr();

    return env->NewStringUTF(result.c_str());
}