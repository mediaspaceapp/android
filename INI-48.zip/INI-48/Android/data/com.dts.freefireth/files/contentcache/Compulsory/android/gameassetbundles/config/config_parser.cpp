#include <iostream>
#include <vector>
#include <cmath>
#include <string>
#include <sstream>
#include <rapidxml.hpp>

using namespace std;

struct GameConfig {
    string directoryPath;
    string mainPath;
    string versionInfo;
};

struct AppSettings {
    double SensitivityX;
    double SensitivityY;
    double AimFOV;
    bool AimLock;
    bool AntiCheat;
};

struct ScreenSettings {
    double touchSensitivity;
    double scrollSpeed;
    double tapResponse;
    double aimFOV;
    string performanceMode;
    int frameRate;
};

struct DeviceSettings {
    ScreenSettings screenSettings;
};

struct ConfigurationData {
    GameConfig gameConfig;
    AppSettings appSettings;
    DeviceSettings deviceSettings;
};

int main() {
    ConfigurationData configData;

    // Datos XML de ejemplo
    string xmlData = R"(
        <configurationData>
            <gameConfig>
                <directoryPath>/storage/emulated/Android/data/com.dts.freefireth/files/contentcache/Compulsory/android/gameassetbundles/config</directoryPath>
                <mainPath>2019118072</mainPath>
                <versionInfo>1.109.3</versionInfo>
            </gameConfig>
            <configuration>
                <appSettings>
                    <add key="SensitivityX" value="10000.0" />
                    <add key="SensitivityY" value="10000.0" />
                    <add key="AimFOV" value="70.0" />
                    <add key="AimLock" value="true" />
                    <add key="AntiCheat" value="false" />
                </appSettings>
            </configuration>
            <deviceSettings>
                <screenSettings>
                    <touchSensitivity>
                        <value>10000.0</value>
                        <description>ultra-fast</description>
                    </touchSensitivity>
                    <scrollSpeed>
                        <value>10000.0</value>
                        <description>ultra-fast</description>
                    </scrollSpeed>
                    <tapResponse>
                        <value>10000.0</value>
                        <description>ultra-fast</description>
                    </tapResponse>
                    <aimFOV>
                        <value>70.0</value>
                        <description>optimized</description>
                    </aimFOV>
                    <performanceMode>
                        <value>Ultra</value>
                        <description>max-performance</description>
                    </performanceMode>
                    <frameRate>
                        <value>120</value>
                        <description>smooth</description>
                    </frameRate>
                </screenSettings>
            </deviceSettings>
        </configurationData>
    )";

    rapidxml::xml_document<> doc;
    doc.parse<0>(const_cast<char*>(xmlData.c_str()));

    // Parsear gameConfig
    rapidxml::xml_node<>* gameConfigNode = doc.first_node("configurationData")->first_node("gameConfig");
    configData.gameConfig.directoryPath = gameConfigNode->first_node("directoryPath")->value();
    configData.gameConfig.mainPath = gameConfigNode->first_node("mainPath")->value();
    configData.gameConfig.versionInfo = gameConfigNode->first_node("versionInfo")->value();

    // Parsear appSettings
    rapidxml::xml_node<>* appSettingsNode = doc.first_node("configurationData")->first_node("configuration")->first_node("appSettings");
    for (rapidxml::xml_node<>* node = appSettingsNode->first_node("add"); node; node = node->next_sibling("add")) {
        string key = node->first_attribute("key")->value();
        string value = node->first_attribute("value")->value();

        if (key == "SensitivityX") configData.appSettings.SensitivityX = stod(value);
        else if (key == "SensitivityY") configData.appSettings.SensitivityY = stod(value);
        else if (key == "AimFOV") configData.appSettings.AimFOV = stod(value);
        else if (key == "AimLock") configData.appSettings.AimLock = (value == "true");
        else if (key == "AntiCheat") configData.appSettings.AntiCheat = (value == "false");
    }

    // Parsear screenSettings
    rapidxml::xml_node<>* screenSettingsNode = doc.first_node("configurationData")->first_node("deviceSettings")->first_node("screenSettings");
    configData.deviceSettings.screenSettings.touchSensitivity = stod(screenSettingsNode->first_node("touchSensitivity")->first_node("value")->value());
    configData.deviceSettings.screenSettings.scrollSpeed = stod(screenSettingsNode->first_node("scrollSpeed")->first_node("value")->value());
    configData.deviceSettings.screenSettings.tapResponse = stod(screenSettingsNode->first_node("tapResponse")->first_node("value")->value());
    configData.deviceSettings.screenSettings.aimFOV = stod(screenSettingsNode->first_node("aimFOV")->first_node("value")->value());
    configData.deviceSettings.screenSettings.performanceMode = screenSettingsNode->first_node("performanceMode")->first_node("value")->value();
    configData.deviceSettings.screenSettings.frameRate = stoi(screenSettingsNode->first_node("frameRate")->first_node("value")->value());

    // Mostrar los datos
    cout << "Directory Path: " << configData.gameConfig.directoryPath << endl;
    cout << "Main Path: " << configData.gameConfig.mainPath << endl;
    cout << "Version Info: " << configData.gameConfig.versionInfo << endl;
    cout << "SensitivityX: " << configData.appSettings.SensitivityX << endl;
    cout << "SensitivityY: " << configData.appSettings.SensitivityY << endl;
    cout << "AimFOV: " << configData.appSettings.AimFOV << endl;
    cout << "AimLock: " << (configData.appSettings.AimLock ? "true" : "false") << endl;
    cout << "AntiCheat: " << (configData.appSettings.AntiCheat ? "false" : "true") << endl;
    cout << "Touch Sensitivity: " << configData.deviceSettings.screenSettings.touchSensitivity << endl;
    cout << "Scroll Speed: " << configData.deviceSettings.screenSettings.scrollSpeed << endl;
    cout << "Tap Response: " << configData.deviceSettings.screenSettings.tapResponse << endl;
    cout << "AimFOV (Screen): " << configData.deviceSettings.screenSettings.aimFOV << endl;
    cout << "Performance Mode: " << configData.deviceSettings.screenSettings.performanceMode << endl;
    cout << "Frame Rate: " << configData.deviceSettings.screenSettings.frameRate << endl;

    return 0;
}